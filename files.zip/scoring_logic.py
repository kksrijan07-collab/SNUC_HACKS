"""
SYNCRO — Proof-of-Work Auditor Engine
Verifies user activity across GitHub, LeetCode, and Monkeytype.
Calculates Discipline Threshold and Squad Health decay.
"""

import httpx
import asyncio
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

@dataclass
class GitHubProof:
    push_events: int = 0
    create_events: int = 0
    total_commits: int = 0
    score: float = 0.0


@dataclass
class LeetCodeProof:
    easy_solved: int = 0
    medium_solved: int = 0
    hard_solved: int = 0
    score: float = 0.0


@dataclass
class MonkeytypeProof:
    wpm: float = 0.0
    consistency: float = 0.0
    score: float = 0.0


@dataclass
class DisciplineResult:
    github: GitHubProof = field(default_factory=GitHubProof)
    leetcode: LeetCodeProof = field(default_factory=LeetCodeProof)
    monkeytype: MonkeytypeProof = field(default_factory=MonkeytypeProof)
    discipline_score: float = 0.0        # 0.0 – 1.0
    threshold_met: bool = False
    health_decay: int = 0                # 0 or 10
    verified_at: str = ""


# ---------------------------------------------------------------------------
# Weights & Thresholds
# ---------------------------------------------------------------------------

WEIGHTS = {
    "github":     0.40,
    "leetcode":   0.35,
    "monkeytype": 0.25,
}

# Minimum raw activity to earn full sub-score
GITHUB_TARGET_COMMITS   = 3
LEETCODE_TARGET_POINTS  = 3   # easy=1, medium=2, hard=4
MONKEYTYPE_TARGET_WPM   = 60
MONKEYTYPE_TARGET_CONS  = 85  # percent

DISCIPLINE_THRESHOLD = 0.60   # Must score >= 60% to avoid health decay


# ---------------------------------------------------------------------------
# GitHub Auditor
# ---------------------------------------------------------------------------

async def fetch_github_proof(username: str, github_token: str) -> GitHubProof:
    """
    Fetches PushEvents and CreateEvents for the last 24 hours
    using the GitHub Events API (unauthenticated: 60 req/hr,
    authenticated: 5000 req/hr).
    """
    since = datetime.now(timezone.utc) - timedelta(hours=24)
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if github_token:
        headers["Authorization"] = f"Bearer {github_token}"

    push_events   = 0
    create_events = 0
    total_commits = 0

    async with httpx.AsyncClient(timeout=10) as client:
        for page in range(1, 4):   # max 3 pages = 90 events
            resp = await client.get(
                f"https://api.github.com/users/{username}/events/public",
                headers=headers,
                params={"per_page": 30, "page": page},
            )
            if resp.status_code != 200:
                logger.warning("GitHub API error %s for user %s", resp.status_code, username)
                break

            events = resp.json()
            if not events:
                break

            for evt in events:
                created = datetime.fromisoformat(
                    evt["created_at"].replace("Z", "+00:00")
                )
                if created < since:
                    break   # events are newest-first; safe to stop

                if evt["type"] == "PushEvent":
                    push_events += 1
                    total_commits += evt.get("payload", {}).get("size", 0)
                elif evt["type"] == "CreateEvent":
                    create_events += 1

    raw = min(total_commits / GITHUB_TARGET_COMMITS, 1.0)
    proof = GitHubProof(
        push_events=push_events,
        create_events=create_events,
        total_commits=total_commits,
        score=round(raw, 4),
    )
    return proof


# ---------------------------------------------------------------------------
# LeetCode Auditor
# ---------------------------------------------------------------------------

LEETCODE_GRAPHQL_URL = "https://leetcode.com/graphql"

RECENT_AC_QUERY = """
query recentAcSubmissions($username: String!, $limit: Int!) {
  recentAcSubmissionList(username: $username, limit: $limit) {
    id
    title
    timestamp
    titleSlug
  }
}
"""

PROBLEM_DIFFICULTY_QUERY = """
query problemDifficulty($titleSlug: String!) {
  question(titleSlug: $titleSlug) {
    difficulty
  }
}
"""

DIFFICULTY_POINTS = {"Easy": 1, "Medium": 2, "Hard": 4}


async def fetch_leetcode_proof(username: str) -> LeetCodeProof:
    """
    Fetches recent accepted submissions (last 24 h) via LeetCode GraphQL.
    Difficulty is resolved per problem; results are deduplicated by titleSlug.
    """
    since_ts = (datetime.now(timezone.utc) - timedelta(hours=24)).timestamp()
    counts = {"Easy": 0, "Medium": 0, "Hard": 0}
    seen_slugs: set[str] = set()

    async with httpx.AsyncClient(timeout=15, headers={"Content-Type": "application/json"}) as client:
        # 1. Get recent ACs
        resp = await client.post(
            LEETCODE_GRAPHQL_URL,
            json={"query": RECENT_AC_QUERY, "variables": {"username": username, "limit": 20}},
        )
        if resp.status_code != 200:
            logger.warning("LeetCode API error %s", resp.status_code)
            return LeetCodeProof()

        submissions = (
            resp.json()
            .get("data", {})
            .get("recentAcSubmissionList", []) or []
        )

        recent = [
            s for s in submissions
            if float(s["timestamp"]) >= since_ts
            and s["titleSlug"] not in seen_slugs
        ]
        for s in recent:
            seen_slugs.add(s["titleSlug"])

        # 2. Fetch difficulty for each unique problem (fan-out)
        async def get_difficulty(slug: str) -> str:
            r = await client.post(
                LEETCODE_GRAPHQL_URL,
                json={"query": PROBLEM_DIFFICULTY_QUERY, "variables": {"titleSlug": slug}},
            )
            if r.status_code == 200:
                return r.json().get("data", {}).get("question", {}).get("difficulty", "Easy")
            return "Easy"

        difficulties = await asyncio.gather(*[get_difficulty(s["titleSlug"]) for s in recent])

        for diff in difficulties:
            if diff in counts:
                counts[diff] += 1

    total_points = (
        counts["Easy"]   * DIFFICULTY_POINTS["Easy"]   +
        counts["Medium"] * DIFFICULTY_POINTS["Medium"] +
        counts["Hard"]   * DIFFICULTY_POINTS["Hard"]
    )
    raw_score = min(total_points / LEETCODE_TARGET_POINTS, 1.0)

    return LeetCodeProof(
        easy_solved=counts["Easy"],
        medium_solved=counts["Medium"],
        hard_solved=counts["Hard"],
        score=round(raw_score, 4),
    )


# ---------------------------------------------------------------------------
# Monkeytype Auditor
# ---------------------------------------------------------------------------

MONKEYTYPE_API_BASE = "https://api.monkeytype.com"


async def fetch_monkeytype_proof(ape_key: str) -> MonkeytypeProof:
    """
    Fetches the most recent test result via /results/last.
    Requires a valid User ApeKey (Bearer token).
    """
    headers = {"Authorization": f"ApeKey {ape_key}"}

    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(f"{MONKEYTYPE_API_BASE}/results/last", headers=headers)

        if resp.status_code != 200:
            logger.warning("Monkeytype API error %s", resp.status_code)
            return MonkeytypeProof()

        data = resp.json().get("data", {})
        wpm         = float(data.get("wpm", 0))
        consistency = float(data.get("consistency", 0))

        # Ensure the result is from the last 24 hours
        ts = data.get("timestamp", 0) / 1000  # ms → s
        if ts < (datetime.now(timezone.utc) - timedelta(hours=24)).timestamp():
            logger.info("Monkeytype last result is older than 24 h — no credit.")
            return MonkeytypeProof()

        wpm_score  = min(wpm / MONKEYTYPE_TARGET_WPM, 1.0)
        cons_score = min(consistency / MONKEYTYPE_TARGET_CONS, 1.0)
        combined   = (wpm_score * 0.6) + (cons_score * 0.4)

        return MonkeytypeProof(
            wpm=round(wpm, 1),
            consistency=round(consistency, 1),
            score=round(combined, 4),
        )


# ---------------------------------------------------------------------------
# Discipline Threshold Calculator
# ---------------------------------------------------------------------------

def calculate_discipline(
    github: GitHubProof,
    leetcode: LeetCodeProof,
    monkeytype: MonkeytypeProof,
) -> DisciplineResult:
    discipline_score = (
        github.score     * WEIGHTS["github"]     +
        leetcode.score   * WEIGHTS["leetcode"]   +
        monkeytype.score * WEIGHTS["monkeytype"]
    )
    threshold_met = discipline_score >= DISCIPLINE_THRESHOLD
    health_decay  = 0 if threshold_met else 10

    return DisciplineResult(
        github=github,
        leetcode=leetcode,
        monkeytype=monkeytype,
        discipline_score=round(discipline_score, 4),
        threshold_met=threshold_met,
        health_decay=health_decay,
        verified_at=datetime.now(timezone.utc).isoformat(),
    )


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------

async def audit_user(
    *,
    github_username: str,
    github_token: str,
    leetcode_username: str,
    monkeytype_ape_key: str,
) -> DisciplineResult:
    """
    Runs all three auditors concurrently, then returns a full DisciplineResult.
    This is the single function called by the API layer.
    """
    github_proof, leetcode_proof, monkeytype_proof = await asyncio.gather(
        fetch_github_proof(github_username, github_token),
        fetch_leetcode_proof(leetcode_username),
        fetch_monkeytype_proof(monkeytype_ape_key),
    )
    return calculate_discipline(github_proof, leetcode_proof, monkeytype_proof)
